---
name: radiology-ai-manuscript-general
description: "General-purpose Radiology/Radiology: Artificial Intelligence manuscript authoring workflow for writing complete medical imaging AI papers from a title, raw model outputs, clinical data, imaging metadata, figures, and tables. Use when no finished Methods or Results are supplied and Codex must reconstruct study design, ask for missing values, draft all sections, generate captions, suggest figures/tables, add references, and audit consistency without using private project-specific content."
---

# General Radiology AI Manuscript Author

## Mission

Use this skill to write a complete medical imaging AI manuscript for Radiology, Radiology: Artificial Intelligence, or a similar journal when the user provides a title or topic, raw model outputs, clinical data, imaging metadata, figures, and tables. This general version must not assume mentor-written Methods or Results. Instead, reconstruct the study from source files, ask for missing values, and draft every section from scratch.

This skill must be safe for public/GitHub use. Do not include or infer any private project, institution, patient, mentor, colleague, folder path, cohort size, model result, figure, or proprietary wording unless provided by the current user in the current task.

## Core Principles

1. Start from the clinical question, not from the model.
2. Trace every scientific number to a source file or explicit user answer.
3. Ask concise questions for missing design values before writing Methods or Results.
4. Use cautious Radiology-style language.
5. Produce a full manuscript plus tables, figure legends, supplement plan, reference list, and final audit.
6. Never fabricate patient counts, exclusion subcounts, model metrics, P values, confidence intervals, hardware, scanner parameters, or ethics information.

## Public Style Anchors

Use public literature for transferable structure and tone:

- CLAIM checklist: Radiology: Artificial Intelligence reporting framework for AI studies.
- Radiology deep learning overview papers: explain AI methods in clinically readable language.
- Radiology diagnostic deep learning papers: clinical hook -> data -> model -> validation -> clinical implication.
- Radiology AI multicenter/external validation studies: clear cohort flow, patient-level partitioning, external test reporting.
- Standard method papers: DeLong, calibration, decision curve analysis, SHAP, Grad-CAM, occlusion sensitivity, relevant network architecture papers.

Do not imitate disease-specific content unless the current manuscript is in the same disease area and the user provides matching data.

## Required Intake Checklist

Ask the user to provide:

- Title or intended clinical task.
- Target journal if known.
- Study design: retrospective/prospective, single/multicenter, dates, institutions.
- Ethics approval status and consent waiver.
- Inclusion/exclusion criteria.
- Initial screened count, eligible count, final count, and class labels.
- Patient-level and lesion/study/image-level identifiers.
- Internal/external or train/validation/test split rules.
- Imaging modality, scanner vendors/models/field strengths, sequence or acquisition parameters.
- Annotation/reference standard: raters, experience, adjudication, tools, outcome definition.
- Preprocessing details: resampling, normalization, registration, segmentation, VOI/ROI creation.
- Model details: architectures, inputs, outputs, training, augmentation, class imbalance, hyperparameters, checkpoint selection, ensemble/fusion.
- Clinical variables and missing-data handling.
- Statistical tests and metrics.
- Raw results: predictions, performance CSVs, confidence intervals, comparisons, calibration, DCA, SHAP/Grad-CAM/occlusion.
- Figures and source data.

If the user only provides files, inspect them first and then ask only for the missing high-impact items.

## Missing-value Question Style

Ask short, concrete questions. Group them by manuscript section.

Examples:

- "What were the study dates for each center?"
- "Were train/test partitions disjoint at the patient, lesion, study, or image level?"
- "What was the reference standard for the outcome?"
- "How many readers annotated or adjudicated labels, and what was their experience?"
- "Which scanner models and sequences were used?"
- "Which model checkpoint rule was used?"
- "Are these metrics from internal validation, external testing, or cross-validation?"
- "Do you want explainability results in the main text or supplement?"

If the user cannot provide a number, leave a placeholder and list it as missing. Do not make one up.

## Manuscript Architecture

Use this order:

1. Title
2. Manuscript type
3. Keywords
4. Abbreviations
5. Summary
6. Key Points
7. Abstract
8. Introduction
9. Methods
10. Results
11. Discussion
12. References
13. Figure legends
14. Tables
15. Supplemental Material

## Title and Central Claim

Convert the user title into one stable central claim. Then mirror it in:

- Summary
- Abstract Purpose
- Abstract Conclusions
- Introduction final paragraph
- Discussion opening
- Conclusion
- Figure 2 workflow title

If the title contains "integrating", the paper must show what streams were integrated and where.

If the title contains "external validation", Results must include external cohort performance.

If the title contains "clinical features", Methods and Results must define those variables and their modeling role.

## Abstract Writing Rules

Purpose:

- One sentence.
- Start with "To develop and externally validate..." when building a model.

Methods:

- Study design and population.
- Data sources and dates.
- Inputs and labels.
- Model and validation.
- Metrics and statistical methods.

Results:

- Cohort size first.
- Main performance next.
- Comparator and statistical comparison next.
- Key secondary finding last.

Conclusion:

- Cautious clinical implication.
- Do not claim outcome improvement unless measured.

## Introduction Logic

Write four paragraphs:

1. Clinical burden and why the prediction/diagnosis task matters.
2. Current clinical or imaging workflow and limitations.
3. AI/deep learning literature gap.
4. Objective and hypothesis.

Good verbs:

- "may help"
- "can extract"
- "has shown promise"
- "remains limited by"
- "was designed to"

Avoid:

- "revolutionize"
- "prove"
- "replace"
- "first ever" unless verified by a formal review.

## Methods Construction

Write Methods from source data. Use a procedural order:

1. Study Design and Participants
2. Imaging Acquisition
3. Reference Standard / Annotation
4. Preprocessing and Input Construction
5. Dataset Partitioning
6. Model Development
7. Clinical or Tabular Modeling
8. Fusion / Ensemble / Ablation / Sensitivity Analysis
9. Explainability
10. Statistical Analysis

Minimum details:

- partition leakage prevention;
- level of analysis;
- missing-data strategy;
- class imbalance handling;
- final model selection rule;
- confidence interval method;
- statistical comparison method;
- software libraries and versions if available.

If any details are unavailable, ask for them or mark them as missing.

## Results Construction

Write Results in this order unless the actual study demands otherwise:

1. Participant/case flow and baseline characteristics.
2. Model development or model selection.
3. Primary model performance.
4. External validation.
5. Comparator models.
6. Calibration and decision utility.
7. Ablation/sensitivity/subgroup analysis.
8. Explainability and representative cases.

Results must be factual. Interpret minimally.

Sentence pattern:

`In the external test cohort, [model] achieved an AUC of X, [secondary metric] of Y, and [calibration metric] of Z. By comparison, [comparator] achieved... The difference in AUC was...`

## Discussion Construction

Write six paragraphs:

1. Principal findings.
2. Clinical or biologic interpretation.
3. Model design and why architecture/input/fusion matters.
4. Comparison with prior work.
5. Intended clinical role and explainability.
6. Limitations and future work.

Tone:

- Make the strongest claim supported by data, then immediately state boundary conditions.
- Use "adjunctive", "decision-support", "may assist", "could help prioritize" for clinical use.
- Do not imply autonomous clinical action.

## Figure Plan

Every figure should answer a reviewer question.

### Figure 1: Cohort Flow

Question: Where did data come from and how were cases excluded and split?

Include:

- screened population;
- inclusion criteria;
- exclusion criteria;
- final cohorts;
- outcome class counts;
- train/validation/test or internal/external strategy.

### Figure 2: Full Workflow

Question: What exactly happens from raw data to final output?

Prompt:

`Create a wide journal-style workflow diagram on a white background. Use left-to-right modules with pale blue headers and thin blue borders. Modules: data sources and imaging inputs; preprocessing/annotation; model inputs or regions of interest; model architecture or model matrix; fusion/ensemble or ablation; clinical/tabular variables if used; validation outputs; clinical interpretation. Use straight arrows, editable labels, small embedded plots for ROC/calibration/decision curve only if real data are available, and leave all counts/metrics as placeholders until verified.`

### Figure 3: Model Selection

Use heatmap or matrix if multiple architectures, inputs, features, sequences, or VOIs were tested.

### Figure 4: Main Performance

Use ROC, precision-recall, calibration, decision curve, and confusion/threshold metrics.

### Figure 5: Clinical or Feature Interpretation

Use OR forest plot, coefficients, SHAP, feature importance, or subgroup performance.

### Figure 6: Explainability / Representative Cases

Use representative images, Grad-CAM/saliency/occlusion, or error analysis.

Place extra examples in supplement if the main figure becomes crowded.

## Figure Captions

Captions must:

- explain the figure purpose;
- define every panel A/B/C/D;
- name cohort and metric;
- define abbreviations;
- state qualitative nature of explainability figures.

Bad caption:

`Figure 4: Model performance.`

Good caption:

`Figure 4: External-test performance of the final fusion model. (A) Receiver operating characteristic curves for the final model and comparator models. (B) Precision-recall curves. (C) Calibration curves with Brier scores. (D) Decision curve analysis showing net benefit across threshold probabilities.`

## Table Plan

Table 1: characteristics by cohort or partition.

Table 2: model performance or clinical predictors.

Table 3: comparisons with baseline models.

Table 4: subgroup/ablation/sensitivity analysis if central.

Supplementary tables:

- imaging protocol;
- hyperparameters;
- full model matrix;
- missing-data profile;
- additional subgroup/error analyses.

Always define denominator, percent basis, confidence interval method, and threshold.

## Reference Strategy

Use references for:

- disease burden and clinical management;
- imaging modality and diagnostic background;
- prior AI studies in the same task;
- model architectures;
- reporting standards;
- performance statistics;
- explainability methods.

Use DOI/PMID when available. Do not cite papers that do not support the sentence.

## Final Output Checklist

Deliver:

- final DOCX;
- missing-item list;
- figure/table inventory;
- data-provenance note if requested;
- render QA status.

Check:

- all sections present;
- title claim is synchronized;
- all figures/tables cited;
- all captions complete;
- all references numbered sequentially;
- no fabricated data;
- no unresolved placeholders except intentionally listed missing items;
- method details satisfy CLAIM-style reporting.

