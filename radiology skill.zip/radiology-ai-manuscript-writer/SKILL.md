---
name: radiology-ai-manuscript-writer
description: "Write, revise, audit, and complete Radiology: Artificial Intelligence-style medical imaging AI manuscripts from DOCX/PDF manuscripts, Results folders, clinical spreadsheets, patient split files, figures, tables, and mentor-written Methods/Results. Use for spine MRI deep learning manuscripts, image-clinical fusion papers, figure/table/caption planning, data consistency checks, and journal-style polishing."
---

# Radiology AI Manuscript Writer

## Purpose

Use this skill to turn a partially written radiology AI project into a complete, internally consistent manuscript. The expected input is usually a mixture of a Word manuscript, mentor-written Methods/Results, a `Results` folder, clinical Excel files, split Excel files, generated figures, and one or more example papers. The output should be a polished Radiology: Artificial Intelligence-style manuscript with coherent title, Summary, Key Points, Abstract, Introduction, Methods, Results, Discussion, figure legends, tables, supplements, and final consistency checks.

This skill is tuned for spine MRI deep learning studies like prediction of pathological vertebral fractures in spinal metastasis, but the workflow generalizes to other imaging AI studies.

## Non-negotiable Rules

1. **Do not invent numerical study data.** If a number affects cohort flow, model performance, clinical predictors, p values, confidence intervals, table entries, or figure annotations, trace it to a source. Acceptable sources include mentor-written Methods/Results, the project `Results` folder, clinical spreadsheets, split spreadsheets, and explicit user-provided values. If a detail is unknown, mark it as missing or use an aggregate count only.
2. **Keep final selected-model facts honest.** If the model matrix tests tumor, peritumoral, and whole-vertebra inputs but the final selected image model is tumor-based, write exactly that. Do not promote the paper as a peritumoral dual-stream architecture unless the data truly support it.
3. **Treat SHAP, GradCAM, occlusion maps, and decision curves as supportive evidence.** They can support clinical plausibility or model behavior, not causality.
4. **Preserve mentor-written Methods/Results unless the user asks for rewriting.** Polish surrounding sections around fixed Methods/Results rather than silently changing final numbers or experimental design.
5. **Always sync the title with the whole manuscript.** If the title changes, update Summary, Purpose, Conclusion, Keywords, Introduction final paragraph, Discussion opening, and final conclusion so the central claim is identical everywhere.
6. **Every figure needs a real caption.** Captions must explain panels A/B/C/D and define abbreviations. A caption that only says "model performance" is too brief.
7. **Render or structurally verify DOCX output.** Use the document tooling to render if available. If LibreOffice is missing, explicitly report that visual render QA could not be performed and do structural/text checks instead.

## Source Inventory Workflow

Before writing, scan the project folder and classify files:

- **Main DOCX manuscript:** latest or user-designated final version. If the user names a file, obey that file even if another file is newer.
- **Results folder:** model metrics, figure CSVs, generated PNGs, SHAP/GradCAM/occlusion outputs, pairwise tests, seed stability, ablation data.
- **Clinical workbook:** baseline clinical variables and fracture labels. Beware Chinese paths; copy to an ASCII temp name if a tool cannot read the path.
- **Patient split workbook:** train/test or internal/external assignment. In this project, train was the internal development cohort and test was the external test cohort.
- **Example paper/PDF:** use for structure, figure grammar, and caption style, not for copying scientific claims or data.
- **Generated manuscript notes:** prior playbooks, figure-style notes, extracted text, extracted figures, and consistency reviews may contain useful local lessons.

For the fracture-risk project, the main proven source hierarchy was:

- `Results` folder for AUC/AP/Brier, pairwise AUC, clinical ORs, fusion weights, image model matrix, and repeated-seed stability.
- `临床.xlsx` plus the patient split workbook for cohort characteristics.
- Mentor Methods/Results for fixed design language, MRI acquisition, preprocessing, and formal result paragraphs.
- User-provided values for screening dates and screened-patient counts in Figure 1.
- The IRB approval number remained missing and must not be invented.

## Radiology AI Article Shape

Use this overall order unless the target journal or user says otherwise:

1. Title
2. Manuscript type if required
3. Keywords
4. Abbreviations if required
5. Summary
6. Key Points
7. Abstract
8. Introduction
9. Methods
10. Results
11. Discussion
12. References
13. Figure legends
14. Tables
15. Supplementary material

The paper should read as a clinical problem solved by a controlled AI workflow, not as a model showcase.

Preferred logic:

1. Clinical burden and decision point.
2. Why current clinical/imaging assessment is insufficient.
3. Why MRI contains fracture- or diagnosis-relevant signal.
4. What AI workflow was built to extract and integrate that signal.
5. How internal and external validation support clinical usefulness.
6. What the model gets wrong or where uncertainty remains.

Avoid:

- "first", "novel", "breakthrough", "confirmed", "proved", "superior to all".
- Treating the best single metric as the whole story.
- Hiding conflicting results; explain them conservatively.
- Reusing a senior paper's disease task, sequence names, cohort labels, or action labels when they do not match the current study.

## Title Discipline

The title is the thesis. After any title change, align:

- Summary first sentence
- Abstract Purpose
- Abstract Conclusions
- Keywords
- Introduction final paragraph
- Discussion first paragraph
- Final conclusion paragraph
- Figure 2 workflow title if it contains the model name
- Running terminology in figure legends and table titles

Example final title for this project:

`A Deep Learning Model Integrating Tumor, Peritumoral, and Clinical Features for Prediction of Pathological Vertebral Fractures in Spinal Metastasis`

If using this title, do not let the manuscript keep saying only "tumor-focused MRI-clinical fusion model." A better aligned wording is:

- "a deep learning model integrating tumor, peritumoral, and clinical features"
- "tumor and peritumoral MRI feature spaces were evaluated"
- "selected image-derived risk was integrated with clinical risk factors"

At the same time, if the final selected image fusion uses tumor-based DenseNet121 and tumor-based Swin-Transformer, keep that result explicit in Results and Discussion.

## Front Matter

### Summary

One compact sentence. Include task, inputs, validation, and main result. Avoid too many metrics.

Pattern:

`An externally validated [AI/deep learning] model [did clinical task] by integrating [input streams], achieving [primary external metric] and outperforming [comparators].`

For the fracture-risk manuscript, a good direction is:

`An externally validated deep learning model that evaluated tumor and peritumoral MRI feature spaces and integrated selected image-derived risk with clinical factors predicted pathological vertebral fractures in spinal metastasis, achieving an external-test AUC of 0.905 and outperforming image-only and clinical-only models.`

### Key Points

Use 2-3 bullets. Each bullet should contain one clear claim with a number if possible.

Bullet order:

1. Cohort and primary performance.
2. Comparison against image-only and clinical-only models.
3. Clinical interpretability or biologic plausibility.

Style:

- "In this retrospective multicenter study..."
- "In the external test cohort..."
- "Clinical feature analysis identified..."

### Abstract

Use a structured abstract.

Purpose:

- One sentence.
- Start with "To develop and externally validate..." or "To evaluate..."
- Match the title wording exactly.

Methods:

- Include design, centers/dates if available, patient/sample count, internal/external split, MRI sequences, VOIs, model families, fusion method, clinical model, and metrics.
- Do not overload this paragraph with every hyperparameter.

Results:

- Start with the final model's main internal/external performance.
- Then state comparator performance and statistical comparison.
- Then clinical predictors or interpretability if central.

Conclusions:

- Say what the model "may support" clinically.
- Avoid "will improve outcomes" unless tested prospectively.

## Introduction Structure

Use four paragraphs.

### Paragraph 1: Clinical Hook

Name the disease and consequence. For vertebral fracture:

- Spinal metastases are common and clinically consequential.
- Pathological vertebral fracture causes pain, deformity, neurologic compromise, mobility loss, and treatment disruption.
- The clinical decision is risk assessment for stabilization, radiotherapy planning, or multidisciplinary review.

### Paragraph 2: Current Assessment Gap

Discuss SINS, qualitative MRI review, radiographic morphology, pain, tumor type, and instability scoring. Explain why these are helpful but incomplete:

- partly subjective
- may not capture three-dimensional tumor burden
- may not quantify marrow replacement, cortical compromise, posterior element involvement, or interactions with systemic factors

### Paragraph 3: AI and Literature Gap

Position deep learning without hype:

- Deep learning can extract volumetric imaging features.
- Prior work may focus on segmentation, primary tumor site classification, benign/malignant fracture differentiation, radiomics, or post-radiotherapy fracture.
- Gap: fewer externally validated vertebral-level pretreatment/pre-fracture models integrating image-derived and clinical risk.

### Paragraph 4: Study Aim

Repeat the title claim and hypothesis. Include exact inputs and comparison:

- tumor/peritumoral/whole-vertebra VOIs
- CNN and Transformer image models
- clinical-only model
- image-clinical fusion
- external validation

## Methods Structure

Methods should be procedural, reproducible, and calm. Use mostly passive voice. Do not editorialize.

Recommended subsections:

1. Study Population and Cohort Construction
2. MRI Acquisition, VOI Annotation, and Tensor Construction
3. General Model Development and Validation Framework
4. Image-only Model Matrix
5. Image-only Fusion Model
6. Sequence Ablation and Stability Analysis
7. Clinical-only Model
8. Image-clinical Fusion Model
9. Statistical Analysis

Details to include:

- Retrospective/multicenter design.
- IRB approval and consent waiver. Use `[approval numbers]` only as a visible placeholder if unknown.
- Center dates and inclusion/exclusion criteria.
- Patient-level partitioning to avoid leakage.
- MRI sequences and acquisition parameters, with table/supplement pointer.
- Annotation tool and annotator experience.
- VOI definitions: tumor, peritumoral region, whole vertebra.
- Preprocessing: bias correction, resampling, intensity clipping, z-score normalization, bounding box, tensor size, channel stacking.
- Model families and exact selection logic.
- Missing data handling for clinical variables.
- Metrics: AUC, AP, Brier, accuracy, sensitivity, specificity, PPV, NPV, F1, calibration, DCA.
- Statistical tests: DeLong or paired bootstrap as appropriate; report two-sided P values.

## Results Structure

Order the Results as an evidence chain:

1. Cohort characteristics and fracture status.
2. Image-only model matrix and selected image models.
3. Image-only CNN-Transformer fusion performance.
4. MRI sequence ablation and repeated-seed stability.
5. Clinical feature analysis and clinical-only model.
6. Final image-clinical fusion model and pairwise comparison.

Results paragraphs should follow this rhythm:

1. Define the comparison or cohort.
2. Report primary metric.
3. Report supporting metrics.
4. Report statistical comparison.
5. Add only a brief descriptive interpretation if needed.

Example:

`In the external test cohort, the image-clinical fusion model achieved an AUC of X, AP of Y, and Brier score of Z. By comparison, the image-only and clinical-only models achieved AUCs of A and B, respectively. The fusion model showed a higher AUC than image-only prediction (Delta AUC, ..., P = ...) and clinical-only prediction (Delta AUC, ..., P = ...).`

## Discussion Structure

Use six paragraphs.

### Paragraph 1: Principal Findings

Restate the study design and the main external result. Say the model outperformed comparators if statistically supported. Link to clinical meaning.

### Paragraph 2: Why Fusion Helps

Explain complementarity:

- MRI-derived features encode tumor burden, marrow replacement, cortical compromise, edema, and spatial weakening.
- Clinical variables encode tumor biology, mechanical instability, prior treatment, pain, and systemic metabolism.
- Fusion coefficients or pairwise improvement support nonredundancy.

### Paragraph 3: Image Model Behavior

Explain why selected CNN/Transformer models make sense:

- CNNs emphasize local texture and edge patterns.
- Transformers can represent broader spatial relationships.
- If tumor-based models were selected, say that the final selected image model should not be interpreted as a generic peritumoral dual-stream architecture.
- If peritumoral models performed variably, say so transparently.

### Paragraph 4: Sequence Ablation and Stability

If single-run ablation and repeated-seed analysis disagree, do not hide it. Use this logic:

- Single-run external estimates can be unstable in modest external cohorts.
- Repeated-seed paired analysis is stronger evidence for stability.
- T1WI may capture marrow replacement/destruction; FS-T2WI may add edema and surrounding marrow response.
- Retain the full sequence input if repeated-seed evidence supports it.

### Paragraph 5: Clinical Predictors and Explainability

Discuss ORs, SHAP, GradCAM, and occlusion maps as a convergent evidence chain:

- Osteolytic metastasis: destructive tumor-bone interaction.
- SINS: mechanical instability.
- Prior radiotherapy: treatment history and possible bone vulnerability.
- Serum phosphorus: systemic mineral metabolism.
- SHAP: model reliance on clinically plausible variables.
- GradCAM/occlusion: attention to lesion-bearing vertebral regions.

### Paragraph 6: Clinical Use, Limitations, Future Work

Position as decision support:

- adjunctive vertebral-level risk score
- multidisciplinary discussion
- closer review or stabilization consideration
- not a standalone replacement for radiologist/spine oncology assessment

Limitations to consider:

- retrospective design
- limited external test cohort
- selection bias
- variable MRI protocols
- fracture status from records/imaging rather than prospective biomechanical testing
- missing clinical variables
- no CT bone density or biomechanics
- need prospective validation and workflow integration

## Sentence-Level Style

Preferred verbs:

- achieved
- demonstrated
- showed
- was associated with
- may support
- may reflect
- suggests
- was evaluated
- was integrated

Preferred transitions:

- "By comparison,"
- "In contrast,"
- "However,"
- "This may reflect..."
- "These findings suggest..."
- "This result should be interpreted cautiously because..."

Avoid:

- "proved"
- "confirmed"
- "revolutionary"
- "excellent" unless journal style permits and data clearly support it
- "robust" unless backed by external validation or repeated-seed/sensitivity analysis
- "perfect"
- "biological link is clear"
- "the model can replace clinicians"

Punctuation and style:

- Use `P = .009`, not `p=0.009`, if following Radiology style.
- Use `95% CI, 0.0171-0.1570`.
- Use `AUC`, `AP`, and `Brier score` consistently.
- Define abbreviations at first use.
- Use `NPV`, not `NP`.
- Be consistent with `pathologic` vs `pathological`; if the title says `pathological`, align front matter and major claims.
- Be consistent with `spinal metastasis` vs `spinal metastases`; title may use singular disease category, while prose often uses plural for patient lesions.
- Avoid negative letter spacing or special punctuation in generated DOCX. Plain ASCII hyphens are safest.

## Tables

### Table 1: Cohort Characteristics and Fracture Status

Purpose: prove the internal and external cohorts are defined correctly.

Minimum columns:

- Characteristic
- Overall if helpful
- Internal development cohort
- External test cohort

For this project, train in the split workbook means internal development cohort and test means external test cohort. Verify against patient IDs and fracture labels before writing.

Include:

- patients and vertebral-level samples
- fracture/non-fracture counts
- age and sex if available
- spinal level if available
- primary tumor type if available
- metastasis type
- SINS
- pain type
- posterior element involvement
- prior radiotherapy
- relevant laboratory markers

Note language:

`Unless otherwise noted, values are vertebral-level samples, with percentages in parentheses.`

If patient count and vertebral-level sample count differ, state both and do not mix denominators.

### Table 2: Multivariable Clinical Predictors

Purpose: make the clinical model interpretable.

Columns:

- Predictor
- Odds ratio (95% CI)
- P value

Use exact ORs and CIs from model output. Do not round inconsistently across text and table.

### Table 3: Model Performance

Purpose: compare image-only, clinical-only, and fusion models.

Rows:

- AUC
- AP
- Brier score
- accuracy
- sensitivity
- specificity
- PPV
- NPV
- F1 score

Columns:

- internal image-only
- internal clinical-only
- internal fusion
- external image-only
- external clinical-only
- external fusion

If table width is too large, split internal and external into separate bands or use a compact layout.

### Table 4: Pairwise AUC Comparisons

Purpose: support comparative claims.

Include:

- comparison
- cohort
- AUC difference
- 95% CI
- P value
- test method

### Supplementary Tables

Useful supplements:

- MRI acquisition parameters.
- Image-only model matrix.
- Repeated-seed stability.
- Sequence ablation if the source CSV/data are complete.
- Additional subgroup or error analysis if available.

Do not create a sequence-ablation table from an empty CSV. If the source file only has headers, report it as unavailable or rely on text values explicitly provided elsewhere.

## Figure Suite

Each figure should answer one reviewer question. Avoid making figures decorative.

### Figure 1: Patient Selection and Cohort Allocation

Reviewer question: where did the data come from, and were internal/external cohorts separated?

Best structure:

- Two vertical tracks: internal development cohort on the left and external test cohort on the right.
- Top boxes: center, dates, screened population.
- Shared central inclusion criteria if identical.
- Separate exclusion boxes for each center/cohort.
- Mid boxes: screened or included counts.
- Bottom boxes: final patient count, vertebral-level sample count, fracture/non-fracture counts.
- Internal bottom branch: five-fold cross-validation or train/validation split.
- External bottom branch: independent testing only.

Writing rules:

- Show exact dates and counts.
- If per-exclusion counts are not recorded, use aggregate excluded count and list reasons without item-level n.
- Do not fabricate item-level exclusion counts.
- Make the caption explain internal/external cohorts, eligibility, exclusions, final counts, fracture status, and validation strategy.

Figure 1 caption pattern:

`Figure 1: Patient selection and cohort allocation. The flow diagram shows the internal development and external test cohorts, eligibility criteria, exclusions during screening, final patient and vertebral-level sample counts, fracture status, and validation strategy.`

Visual style from the senior example:

- White background.
- Thin black boxes and straight connector lines.
- Two balanced columns.
- Serif or journal-like font.
- Small but readable text.
- Avoid decorative colors unless needed.

### Figure 2: Overall MRI-Clinical Fusion Workflow

Reviewer question: what exactly is the AI system from MRI input to final prediction?

Recommended modules:

1. Cohort definition and MRI input.
2. Preprocessing and tensor construction.
3. VOI generation: tumor, peritumoral region, whole vertebra.
4. Image-only model matrix: ResNet50, DenseNet121, Swin-Transformer by VOI.
5. Selected image fusion: DenseNet121 plus Swin-Transformer if supported.
6. Clinical-only model.
7. Final image-clinical stacking.
8. External validation outputs.

If using a graphical workflow style:

- Wide horizontal canvas.
- White or very light grid background.
- Pale blue module headers.
- Blue-outlined rounded panels.
- Left-to-right arrows.
- Green highlight only for selected/primary model components.
- Medical colors: red/orange for tumor, yellow/orange for peritumoral region, blue for model/data elements.

Do not copy senior article details such as WAMNet, HALS, CE-T1WI, primary tumor classification, or Bone-RADS language unless they are actually part of the current study.

Caption must define each major block and the final output.

### Figure 3: Image-only Model Matrix

Reviewer question: why were these image models selected?

Structure:

- 3 architectures x 3 VOIs.
- Internal and external performance displayed separately.
- Heatmap, grouped bars, or matrix table.
- Display AUC as primary; AP/Brier can be companion metrics.
- Mark selected models with a border/star/label.

Caption must say:

- which rows/columns represent architecture and VOI
- what metrics are shown
- which models were selected and why
- whether internal and external panels are separate

For this project:

- Tumor DenseNet121 had strongest internal validation.
- Tumor Swin-Transformer had comparable external discrimination/high AP.
- Peritumoral ResNet50 may show high external AUC but lower internal performance, so do not overclaim it.

### Figure 4: Image-only Fusion Performance

Reviewer question: did fusing selected image models improve image-only prediction?

Panels:

- A: ROC curves for selected individual image models and image-only fusion.
- B: Precision-recall curves.
- C: Calibration curves with Brier scores.
- D: Decision curve analysis.

Caption must define all panels and name the models.

### Figure 5: MRI Sequence Ablation and Repeated-seed Stability

Reviewer question: which MRI sequences matter, and is the answer stable?

Panels:

- A: single-run external sequence-ablation performance.
- B: paired repeated-seed comparison between full model and reduced model.
- Optional C/D: AP and Brier stability, or seed-level paired dot plots.

Critical interpretation:

- Single-run ablation and repeated-seed stability answer different questions.
- If single-run T1WI or T1WI+T2WI appears higher than the full model, do not conclude FS-T2WI is useless if repeated-seed analysis favors the full model.
- Say "single-run estimates were variable" and "repeated-seed paired analysis supported retaining the full three-sequence input."

Caption pattern:

`Figure 5: MRI sequence ablation and repeated-seed stability analysis. Panel A shows single-run external sequence-ablation performance, and panel B shows paired repeated-seed comparison between the full three-sequence model and the reduced T1WI plus T2WI model.`

If there are more panels, explain each panel separately.

### Figure 6: Clinical Predictors and Clinical-model Performance

Reviewer question: do clinical predictors make sense and how well does the clinical-only model perform?

Panels:

- A: multivariable OR forest plot.
- B: SHAP or mean absolute contribution plot.
- C: external ROC curve.
- D: calibration plot.
- Optional E: decision curve.
- Optional F: selected threshold metrics.

Caption must state what A/B/C/D are. Do not write only "clinical predictors."

Interpretation:

- OR plot = statistical association.
- SHAP/contribution = model reliance.
- ROC/calibration = predictive performance.
- These are complementary, not interchangeable.

### Figure 7: Final Image-clinical Fusion Performance

Reviewer question: does the final model improve clinically relevant performance?

Panels:

- A: ROC curves for image-only, clinical-only, fusion.
- B: PR curves.
- C: calibration curves with Brier score.
- D: decision curve analysis.
- E: summary metrics.
- F: standardized fusion weights.

Caption must mention all models and all panels:

`Figure 7: Final image-clinical fusion performance in the external test cohort. (A) ROC curves for the image-only, clinical-only, and image-clinical models. (B) Precision-recall curves for the three models. (C) Calibration curves with Brier scores. (D) Decision curve analysis showing net benefit across threshold probabilities. (E) Summary performance metrics including AUC, AP, and Brier score. (F) Final standardized fusion weights for the image logit and clinical logit.`

## Figure Caption Rules

Every caption should include:

1. Figure number and short title.
2. One sentence explaining the figure's purpose.
3. Panel-by-panel explanation.
4. Abbreviation definitions if not already obvious.
5. Cohort level: internal, external, or both.
6. Metric level: AUC/AP/Brier/OR/SHAP/DCA as applicable.

Common fixes:

- If a figure has panels A-D, never leave the caption at one sentence.
- If a figure contains a heatmap, say what color intensity means.
- If a figure contains a calibration curve, mention Brier score.
- If a figure contains DCA, say net benefit across threshold probabilities.
- If a figure contains fusion weights, say image logit and clinical logit.
- If a figure contains SHAP, avoid causal wording.

## Supplementary Material

Good supplement order:

1. Study population details.
2. MRI acquisition parameters.
3. VOI annotation and fracture-status assessment.
4. Preprocessing and tensor construction.
5. Model training and optimization.
6. Fusion and statistical analysis.
7. Explainability and representative cases.

Useful supplementary figures:

- Representative cases.
- GradCAM cases.
- Occlusion sensitivity cases.
- SHAP waterfall/beeswarm.
- Additional subgroup/error analysis.

Useful supplementary tables:

- MRI acquisition.
- Image model matrix.
- Seed stability.
- Additional clinical characteristics.
- Hyperparameters if needed.

## Data Consistency Checklist

Before finalizing:

- Title matches Summary, Purpose, Conclusions, Keywords, Introduction aim, Discussion opening, and final conclusion.
- Patient counts match across Figure 1, Methods, Results, Table 1, Abstract, and Summary.
- Vertebral-level sample counts are not confused with patient counts.
- Internal/external labels match the split workbook.
- Fracture/non-fracture counts match the label source.
- AUC/AP/Brier values match CSVs and generated figures.
- Pairwise AUC differences and P values match the comparison table.
- Clinical ORs match the clinical forest data.
- Fusion weights match the figure data.
- Figure numbering is sequential after inserting or deleting figures.
- In-text figure and table references exist for every figure/table.
- Figure captions explain all panels.
- Table notes define denominators and abbreviations.
- No `XX`, `TBD`, `TODO`, or accidental placeholders remain except intentionally flagged IRB approval numbers.
- References cited in claims exist and are plausible for the statement.
- CLAIM items are covered: study design, data source, eligibility, preprocessing, annotation, partitioning, model, training, evaluation, external validation, interpretability, limitations.

## Completion Audit for a DOCX Manuscript

Use document tooling to inspect:

- Number of figures and inline images.
- Number of Word tables.
- Captions and table titles.
- Placeholder strings.
- First 30 paragraphs for front matter consistency.
- All in-text references to Figure/Table/Supplement.

If rendering is available, render every page and inspect:

- title page and abstract
- pages with large tables
- pages with figures and captions
- supplement tables
- line breaks in long title
- figure/caption separation
- table clipping

If rendering fails because LibreOffice is missing, say so and report that only structural/text QA was completed.

## Example Anchors from the Fracture-risk Manuscript

Use these only after verifying against the current user's files:

- Final title: `A Deep Learning Model Integrating Tumor, Peritumoral, and Clinical Features for Prediction of Pathological Vertebral Fractures in Spinal Metastasis`
- Internal development cohort: 345 vertebral-level samples from 148 patients.
- External test cohort: 88 vertebral-level samples from 88 patients.
- Fracture/non-fracture counts: internal 158/187; external 44/44.
- Final image-clinical fusion: internal AUC 0.918, AP 0.908, Brier 0.114; external AUC 0.905, AP 0.912, Brier 0.130.
- External comparators: image-only AUC 0.823; clinical-only AUC 0.849.
- External AUC comparisons: fusion vs image-only Delta AUC 0.0826, P = .009; fusion vs clinical-only Delta AUC 0.0568, P = .047.
- Clinical predictors: prior radiotherapy, osteolytic metastasis, SINS score, and serum phosphorus.
- Missing hard item: IRB approval numbers.

Do not assume these values apply to a new project.

## How to Use an Example Paper

Use a senior or example Radiology AI paper for:

- front matter order
- cohort flow diagram logic
- figure suite sequencing
- table note style
- caption density
- conservative clinical tone

Do not copy:

- disease-specific claims
- model names
- sequence sets
- cohort counts
- exclusion categories
- labels such as "actionable" if not used
- performance metrics
- figure panels

From the example proof in this workspace, reusable structure was:

- Figure 1: two-track internal/external cohort flowchart with inclusion/exclusion and final partitions.
- Figure 2: full system architecture from institutions/data to model training and performance analysis.
- Figure 3: training/validation curves for model development.
- Figure 4: grouped performance comparison across internal/external sets.
- Figure 5: ROC curves plus confusion matrices.
- Figure 6: representative case with MRI sequences, model mask/output, and final prediction probability.

For a fracture-risk paper, adapt the sequence to:

- cohort flow
- MRI-clinical workflow
- image model matrix
- image-only fusion
- sequence ablation/stability
- clinical predictors/performance
- final fusion performance

## Minimal End-to-End Procedure

1. Identify the final manuscript file and make a backup.
2. Extract text, captions, table titles, figure count, and placeholder strings.
3. Inventory `Results`, clinical spreadsheets, split spreadsheets, and all figures.
4. Build a data provenance table in notes: number -> source file -> manuscript location.
5. Align title/front matter first.
6. Lock Methods/Results numbers before polishing prose.
7. Insert or update Table 1 from clinical and split data.
8. Add model performance, clinical predictor, comparison, and supplement tables from `Results`.
9. Insert missing figures and renumber downstream figures.
10. Expand figure captions panel by panel.
11. Add in-text references for every table and figure.
12. Polish Introduction and Discussion around the exact data.
13. Run placeholder and consistency scans.
14. Render DOCX if possible; otherwise disclose structural QA only.
15. Return the final DOCX plus a short list of remaining hard missing items.
